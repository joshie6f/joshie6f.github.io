TrueTypeFont: Electrox
Dennis Ludlow 2002 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there everyone. This was a font i designed for a client resembling
the cartoon Static Shock. It has been a while since i stopped designing fonts but 
ran across this one on my hard drive. Hope you all enjoy! Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"